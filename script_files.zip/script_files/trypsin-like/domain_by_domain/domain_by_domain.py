#!/usr/bin/env python

#chop proteins up into domains and align
import re
import subprocess
import sys
import math
import numpy
import glob


from id_matrix import struc_matrix

def write_file(super,names,filename):
	f = open(filename, "w+")

	f.write("#mega\n!TITLE distance matrix; \n!Format DataType=distance;\n"
		+ "!Description \n\tproteins;\n\n");

	for name in range(len(names)):
		f.write("#" + names[name] + "\n")

	f.write("\n")

	for r_num in range(len(super)):
		row = super[r_num];

		for i in range(r_num):
			f.write(str(row[i]) + "\t");

		f.write("\n")

def clean_file_names(pdb_files):
	names = list()

	for file in pdb_files:
		file = file.split("/")[1]
		name = file.split(".pdb")[0]

		names.append(name)

	return names

def join_domains(dist1, dist2):
	size = len(dist1)

	dist_matrix = [[0]*size for i in range(size)]

	for i in range(len(dist1)):
		for j in range(len(dist2)):

			dist_matrix[i][j] = dist1[i][j] + dist2[i][j]

		#mean = [numpy.mean(j) for j in zip(dist1[i],dist2[i])]

		#add = [numpy.add(j) for j in zip(dist1[i],dist2[i])]

		#joint.append(mean)

	return(dist_matrix)

pdb_files_1 = (glob.glob(sys.argv[1] + "/*.pdb"))

pdb_files_2 = (glob.glob(sys.argv[2] + "/*.pdb"))

names_1 = clean_file_names(pdb_files_1)

names_2 = clean_file_names(pdb_files_2)


struc_dist_1 = struc_matrix(pdb_files_1, p=False)
#print(struc_dist_1)

struc_dist_2 = struc_matrix(pdb_files_2, p=False)
#print(struc_dist_2)

joint_dist = join_domains(struc_dist_1,struc_dist_2)
#print(joint_dist)

write_file(struc_dist_1, names_1, "distmatrix_dom1.meg")
write_file(struc_dist_2, names_2, "distmatrix_dom2.meg")
write_file(struc_dist_2, names_1, "distmatrix_dom_joint.meg")


