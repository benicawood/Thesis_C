library("dendextend")
library("fossil")
library("dynamicTreeCut")

#mega file to distance 
mega_to_dist <- function(filename){
  #process file
  file <- readLines(file(filename,open="r"))
  
  names = c()
  dist = c()
  
  for (line in file) {
    if (grepl("^#.*", line) && line != "#mega"){
      line = unlist(strsplit(line, "#"))
      names = c(names, line[2])
    }
    else if (grepl("^[0-9]", line)){
      line = strsplit(line,"\t")
      dist = c(dist, line)
    }
  }
  
  #put distances in matrix
  distances = data.frame(matrix(ncol = length(names), nrow = length(names)))
  
  for (i in c(1:length(names))){
    for (j in c(1:length(names))){
      if (i == j){
        distances[i,j] = 0
      }
      else if (i < j) {
        if (is.null(unlist(dist[[j-1]][i])) == FALSE){
          val = dist[[j-1]][i]
          distances[i,j] = val
          distances[j,i] = val
        }
      }
    }
  }

  distances = setNames(distances, names)
  distances = as.dist(distances)
  return(distances)
}


#create dendrogram
dist_seq = mega_to_dist("seqmatrix.meg") 
dist_str = mega_to_dist("distmatrix.meg")

h_seq = dist_seq %>% hclust
h_str = hclust(dist_str, method = "average")

dend_seq = as.dendrogram(h_seq)
dend_str = as.dendrogram(h_str)

dend_seq %>% plot
dend_str %>% plot

tanglegram(dend_seq, dend_str)

#entanglement
dends_seq_str <- dendlist(dend_seq, dend_str)
dends_seq_str %>% entanglement

#untangle
set.seed(3958)
x <- dends_seq_str %>% untangle(method = "random", R = 10) 
set.seed(3958)
x <- x %>% untangle(method = "random", R = 10) 
x %>% plot(main = "Sequence vs Structure")

cor_bakers_gamma(dend_seq, dend_str)






